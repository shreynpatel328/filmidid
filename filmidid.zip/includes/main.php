<div class="main home">
<div class="listblock" id="v">
<div class="listblock1">
<table width="1000" height="250" cellpadding="0" cellspacing="0">
<th colspan="4" align="left">
<a class="a_heading">Top films</a>
<a class="viewall">VIEW ALL</a>
</th>
<tr valign="top">
<td>
<p class="a_heading1"><a>Comedy</a></p>
<div class="vdo_thumb">
</div>
<div class="vdo_thumb">
</div>
</td>
<td>
<p class="a_heading1"><a>Romantic</a></p>
<div class="vdo_thumb">
</div>
<div class="vdo_thumb">
</div>
</td>
</tr>
<tr>
<td>
<p class="a_heading1"><a>Music</a></p>
<div class="vdo_thumb">
</div>
<div class="vdo_thumb">
</div></td>
<td>
<p class="a_heading1"><a>Fantasy</a></p>
<div class="vdo_thumb">
</div>
<div class="vdo_thumb">
</div>
</td>
</tr>
</table>
</div>
</div>

<div class="listblock" id="a">
<div class="listblock1">
<table width="1000" height="250" cellpadding="0" cellspacing="0">
<th colspan="4" align="left">
<a class="a_heading">Top AD films</a>
<a class="viewall">VIEW ALL</a>
</th>
<tr valign="middle">
<td>
<div class="vdo_thumb">
</div>
</td>
<td>
<div class="vdo_thumb">
</div>
</td>
<td>
<div class="vdo_thumb">
</div>
</td>
<td>
<div class="vdo_thumb">
</div>
</td>
</tr>
</table>
</div>
</div>

<div class="listblock" id="t">
<div class="listblock1">
<table width="980" height="250" cellpadding="0" cellspacing="0">
<th colspan="5" align="left">
<a class="a_heading">Popular Profiles</a>
<a class="viewall">VIEW ALL</a>
</th>
<tr valign="top">
<td>
<p class="a_heading2"><a>Random Profile1</a></p>
<div class="talent_box">
</div>
</td>
<td>
<p class="a_heading2"><a>Random Profile2</a></p>
<div class="talent_box">
</div>
</td>
<td>
<p class="a_heading2"><a>Random Profile3</a></p>
<div class="talent_box">
</div>
</td>
<td>
<p class="a_heading2"><a>Random Profile4</a></p>
<div class="talent_box">
</div>
</td>
</tr>
</table>
</div>
</div>

<div class="listblock" id="r">
<div class="listblock1">
<table width="1000" height="250" cellpadding="0" cellspacing="0">
<th colspan="4" align="left">
<a class="a_heading">Featured Reviews</a>
<a class="viewall">VIEW ALL</a>
</th>
<tr valign="top">
<td>
<p class="a_heading1"><a>Featured Reviews1</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>Featured Reviews2</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>Featured Reviews3</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>Featured Reviews4</a></p>
<div class="review_box">
</div>
</td>
</tr>
</table>
</div>
</div>

<div class="listblock" id="rr">
<div class="listblock1">
<table width="1000" height="200" align="center" cellpadding="0" cellspacing="0">
<th colspan="5" align="left">
<a class="a_heading">Top Reviewers</a>
<a class="viewall">VIEW ALL</a>

</th>
<tr valign="top">
<td>
<p class="a_heading2"><a>Reviewer 1</a></p>
<div class="talent_thumb">
</div>
</td>
<td>
<p class="a_heading2"><a>Reviewer 2</a></p>
<div class="talent_thumb">
</div>
</td>
<td>
<p class="a_heading2"><a>Reviewer 3</a></p>
<div class="talent_thumb">
</div>
</td>
<td>
<p class="a_heading2"><a>Reviewer 4</a></p>
<div class="talent_thumb">
</div>
</td>
<td>
<p class="a_heading2"><a>Pointer</a></p>
<div class="talent_thumb">
</div>
</td>
</tr>
</table>
</div>
</div>


<div class="listblock" id="f">
<div class="listblock1">
<table width="1000" height="250" cellpadding="0" cellspacing="0">
<th colspan="4" align="left">
<a class="a_heading">Featured FORUMS</a>
<a class="viewall">VIEW ALL</a>
</th>
<tr valign="top">
<td>
<p class="a_heading1"><a>TOPIC1</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>TOPIC2</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>TOPIC3</a></p>
<div class="review_box">
</div>
</td>
<td>
<p class="a_heading1"><a>TOPIC4</a></p>
<div class="review_box">
</div>
</td>
</tr>
</table>
</div>
</div>
</div>