<?php 

   $app_id = "140720629436470";
   $app_secret = "82c05fe376aafa18f957c07be2848b1f";
   $my_url = "YOUR_URL";

   session_start();

 ?>