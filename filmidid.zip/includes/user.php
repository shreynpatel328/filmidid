<div class="prof">
<table width="1000" height="400" cellpadding="0" cellspacing="0">
<tr>
<td width="600">
<div class="prof_slider">
<img src="images/bhavan.jpg" width="580" height="380" />
</div>
</td>
<td width="400">
<div class="prof_details">

</div>
</td>
</tr>
</table>

<table width="1000" height="40" cellpadding="0" cellspacing="0">
<tr>
<td>
</td>
<td bgcolor="#333" style="border-radius:0px 0px 15px 15px;" width="600">
</td>
<td>
</td>
</tr>
</table>

<table width="1000" height="400" cellpadding="0" cellspacing="0">
<tr>
<td>
</td>
<td>
</td>
</tr>
</table>

</div>
<script>
$("#float_nav").hide();
</script>