<div class="main home">
<br/><br/>
<table width="1000" height="400" cellspacing="0" cellpadding="0" align="center">
<tr>
<td>
<div id="vdo_panel">
<iframe width="700" height="450" src="http://www.youtube.com/embed/9fygaVv7mps" frameborder="0" allowfullscreen></iframe>
</div>
</td>
<td width="300">
<div id="vdo_dsc">
</div>
</td>
</tr>
</table>
<div id="vdo_nav">

</div>
<div id="vdo_coms">

</div>
</div>
<script>
$("#float_nav").hide();
</script>