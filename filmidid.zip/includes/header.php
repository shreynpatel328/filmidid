<div id="pop_bg"></div>
<div id="pop">
<button id="signup_box_close" >Close</button>
<div id="pop_cont">
<?php
include('login.php');
?>
</div>
</div>


<div class="page">
<div class="header">
	<button id="login_btn">LOGIN</button>
<a href="index.php"><img src="images/logo.png" style="float:left;" height="80" /></a>
<span style="margin-top:25px; font-size:14px; margin-left:30px; position:absolute;">Watch In : </span>
<button id="lang_sel" class="inp_text lang">
select language</button>

<div id="searchbar">
<input class="inp_text searchbarmain" type="text" placeholder="Search" /><img src="images/search.png" height="30" class="lens"/><br/>
<table class="bar_tabs" cellpadding="0" cellspacing="0">
<tr>
<td class="selected">Films</td>
<td>Ad Films</td>
<td>profiles</td>
<td>forums</td>
</tr>
</table>
</div>
<div id="float_nav">
<ul>
<li>top<br/>films</li>
<hr class="hor"/>
<li>top<br/>ad films</li>
<hr class="hor"/>
<li>popular<br/>profiles</li>
<hr class="hor"/>
<li>featured<br/>reviews</li>
<hr class="hor"/>
<li>top<br/>reviewers</li>
<hr class="hor"/>
<li>featured<br/>forums</li>
</ul>
</div>
</div>
</div>

