<?php
include('includes/functions.php');
include('includes/init.php');
set_title('Test title');
//header//
include('includes/header.php');
echo '<br/><br/><br/><br/><br/>';
//page//
include('includes/watch.php');
//footer//
include('includes/fin.php');
?>
